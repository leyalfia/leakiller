# -*- coding: utf-8 -*-
# -*- leakiller -*-
# -*- Version: CL_warnode V.01 2020-*-
# -*- Creator: lea team alphat lovers-*-
from lea.killer import *
from akad.ttypes import *
from thrift.unverting import *
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from thrift import transport, protocol, server
from threading import Thread
from Naked.toolshed.shell import execute_js
from multiprocessing import Pool, Process
from time import sleep
import time, random, multiprocessing, sys, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, pytz, pafy, urllib, urllib.parse
from datetime import timedelta, date
from humanfriendly import format_timespan, format_size, format_number, format_length
from datetime import datetime
import html5lib
import requests,json,urllib3
from random import randint
from bs4 import BeautifulSoup
from googletrans import Translator
import youtube_dl
import pyimgflip

_session = requests.session()
botStart = time.time()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#=================================================================================#
appF = "CHANNELCP\t2.9.1\tAndroid OS\t5.1.1"
token = 'TOKEN PRIMARY'
line = LINE(token,appName=appF)
line.log("Auth Token : " + str(line.authToken))
#=================================================================================#
oepoll = OEPoll(line)
lineProfile = line.getProfile()
lineSettings = line.getSettings()
mid = line.profile.mid
mid = line.getProfile().mid
print ("BOSS : " + mid)
print ("==========[[LOGIN SUCCES]]==========")
#=================================================================================#
creator = ["MID KAMU"]
owner = ["MID KAMU"]
admin = ["MID KAMU"]
staff = ["MID KAMU"]
Bots = ["MID BOT KAMU SEMUA"]
#=================================================================================#
Team = creator + owner + admin + staff + Bots
Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)

blacklist = []
targets = []
_dn = []
warmode = []
welcome = []
msg_dict = {}
msg_dict1 = {}

settings = {"Picture":False,"group":{},"groupPicture":False,"changePicture":False,"autoJoinTicket":False,
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0","Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5","Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0","Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0","Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}
wait = {
    "limit": 1,
    "creator":{},
    "owner":{},
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "staff":{},
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "autoAdd":True,
    'autoJoin':True,
    'autoLeave':False,
    "protectqr":False,
    "protectinvite":False,
    "protectjoin":False,
    "protectkick":False,
    "protectantijs":True,
    "protectcancel":False,
    "backup":True,
    "Danger":True,
    "selfbot":True,
    "Response":"ℓєα αℓρнαт ℓσνєяѕ",
    "comment":"ʟⁱᵏᵉ ʟⁱᵏᵉ & ʟⁱᵏᵉ ᴀʲᵃ - ʙʏ : ℓєα αℓρнαт ℓσνєяѕ",
    "comment1":"ʟⁱᵏᵉ ʟⁱᵏᵉ & ʟⁱᵏᵉ ᴀʲᵃ - ʙʏ : ℓєα αℓρнαт ℓσνєяѕ",
    "comment2":"ʟⁱᵏᵉ ʟⁱᵏᵉ & ʟⁱᵏᵉ ᴀʲᵃ - ʙʏ : ℓєα αℓρнαт ℓσνєяѕ",
    "message":"ᴛᴇʀɪᴍᴀᴋᴀsɪʜ sᴜᴅᴀʜ ᴍᴇɴᴀᴍʙᴀʜᴋᴀɴ sᴀʏᴀ\nsᴇʙᴀɢᴀɪ ᴛᴇᴍᴀɴ ᴀɴᴅᴀ 😎😎😎.",
}
read = {"readPoint":{},"readMember":{},"readTime":{},"ROM":{},}
cctv = {"cyduk":{},"point":{},"sidermem":{}}
#=================================================================================#
helpMessage ="""     ™ ℓєα αℓρнαт ℓσνєяѕ ™
╔═══════════════════╗
╠ℓєα вσт🖕● help
╠ℓєα вσт🖕● cekbot
╠ℓєα вσт🖕● me
╠ℓєα вσт🖕● mid
╠ℓєα вσт🖕● midbots
╠ℓєα вσт🖕● status
╠ℓєα вσт🖕● refresh
╠ℓєα вσт🖕● khilaf
╠ℓєα вσт🖕● sampah
╠ℓєα вσт🖕● restart
╠ℓєα вσт🖕● runtime
╠ℓєα вσт🖕● absen
╠ℓєα вσт🖕● out
╠ℓєα вσт🖕● sp
╠ℓєα вσт🖕● myfriend
╠ℓєα вσт🖕● glist
╠ℓєα вσт🖕● listbot
╠ℓєα вσт🖕● listadmin
╠ℓєα вσт🖕● myname: [nama]
╠ℓєα вσт🖕● updatefoto
╠ℓєα вσт🖕● all/tagall
╠ℓєα вσт🖕● Kick @
╠ℓєα вσт🖕● Vkick [nama]
╠ℓєα вσт🖕● banlist
╠ℓєα вσт🖕● clearban
╠•••••••••••••••••••••••••••••••••••••••
╠•••••COMMAND REMOTE•••••
╠•••••••••••••••••••••••••••••••••••••••
╠ℓєα вσт🖕● out [number]
╠ℓєα вσт🖕● ambilqr [number]
╠ℓєα вσт🖕● glist
╠ℓєα вσт🖕● pass [number]
╚═══════════════════╝"""
#=================================================================================#
mulai = time.time()
tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)
def logError(text):
    line.log("[ Lea__killer ] {}".format(str(text)))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
    with open("leakiller.txt","a") as error:
        error.write("\n[{}] {}".format(str(time), text))

def restart_program(): 
    python = sys.executable
    os.execl(python, python, * sys.argv)
def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     
        import urllib,request
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"

def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))

def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]

def atend():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")

def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      
            time.sleep(0.001)        
            page = page[end_content:]
    return items

def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)

def backupProfile():
    profile = line.getContact(mid)
    settings['myProfile']['displayName'] = profile.displayName
    settings['myProfile']['pictureStatus'] = profile.pictureStatus
    settings['myProfile']['statusMessage'] = profile.statusMessage
    settings['myProfile']['videoProfile'] = profile.videoProfile
    coverId = line.getProfileDetail()['result']['objectId']
    settings['myProfile']['coverId'] = str(coverId)

def sendSticker(to, version, packageId, stickerId):
    contentMetadata = {
        'STKVER': version,
        'STKPKGID': packageId,
        'STKID': stickerId
    }
    line.sendMessage(to, '', contentMetadata, 7)

def backupData():
    try:
        backup1 = Setmain
        f = codecs.open('setting.json','w','utf-8')
        json.dump(backup1, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup2 = settings
        f = codecs.open('settings.json','w','utf-8')
        json.dump(backup2, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup3 = wait
        f = codecs.open('wait.json','w','utf-8')
        json.dump(backup3, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup4 = read
        f = codecs.open('read.json','w','utf-8')
        json.dump(backup4, f, sort_keys=True, indent=4, ensure_ascii=False)        
        return True
    except Exception as error:
        logError(error)
        return False

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d ʜᴀʀɪ %02d ᴊᴀᴍ %02d ᴍᴇɴɪᴛ %02d ᴅᴇᴛɪᴋ' % (days, hours, mins, secs)

def famzmention(to, mids=[]):
    parsed_len = len(mids)//20+1
    result = '╭──「ᴍᴇɴᴛɪᴏɴ_ᴍᴇᴍʙᴇʀs」\n'
    mention = '>>> ™ℓєα αℓρнαт ℓσνєяѕ™ <<<\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1
            result += '│ %i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += '╰──「ᴍᴇɴᴛɪᴏɴ_ᴍᴇᴍʙᴇʀs」'
        if result:
            if result.endswith('\n'): result = result[:-1]
            line.sendMessage(to, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''

def sendMention39(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = " ℓєα αℓρнαт ℓσνєяѕ "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    line.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd

def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
        if op.type == 11:
            if wait["protectqr"] == True:
                try:
                    if line.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            X = line.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            line.kickoutFromGroup(op.param1,[op.param2])
                            line.updateGroup(X)
                            wait["blacklist"][op.param2] = True
                except:
                    pass

            if op.param2 in wait["blacklist"]:
                try:
                    if line.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            X = line.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            line.kickoutFromGroup(op.param1,[op.param2])
                            line.updateGroup(X)
                            wait["blacklist"][op.param2] = True
                except:
                	pass
                
        if op.type == 13:
            if wait["protectinvite"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        inv1 = op.param3.replace('\x1e',',')
                        inv2 = inv1.split(',')
                        for _mid in inv2:
                            if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in staff:
                                line.cancelGroupInvitation(op.param1,[_mid])
                                line.kickoutFromGroup(op.param1,[op.param2])
                                wait["blacklist"][op.param2] = True
                    except:
                        pass

        if op.type == 19:
            if wait["protectkick"] == True:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        line.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass

        if op.type == 13:
            if mid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        line.rejectGroupInvitation(op.param1)
                    else:
                        line.acceptGroupInvitation(op.param1)

        if op.type == 13:
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        inv1 = op.param3.replace('\x1e',',')
                        inv2 = inv1.split(',')
                        for _mid in inv2:
                            if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in staff:
                                line.cancelGroupInvitation(op.param1,[_mid])
                                line.kickoutFromGroup(op.param1,[op.param2])
                                wait["blacklist"][op.param2] = True
                    except:
                        pass

        if op.type == 13:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        inv1 = op.param3.replace('\x1e',',')
                        inv2 = inv1.split(',')
                        for _mid in inv2:
                            if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in staff:
                                line.cancelGroupInvitation(op.param1,[_mid])
                                line.kickoutFromGroup(op.param1,[op.param2])
                                wait["blacklist"][op.param2] = True
                    except:
                        pass

        if op.type == 13:
            if op.param3 in wait["blacklist"]:
                try:
                    line.kickoutFromGroup(op.param1,[op.param2])
                except:
                    pass

        if op.type == 17:
            if wait["protectjoin"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        line.kickoutFromGroup(op.param1,[op.param2])
                        wait["blacklist"][op.param2] = True
                    except Exception as e:
                        print(e)

        if op.type == 32:
            if wait["protectcancel"] == True:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        line.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
#-----------------------------------------------------------------------------------------------------------------------
        if op.type == 19 or op.type == 32:
            if op.param3 in creator:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["protectjoin"] = True
                    wait["protectinvite"] = True
                    wait["protectqr"] = True
                    try:
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.findAndAddContactsByMid(op.param3)
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        pass

            if op.param3 in owner:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["protectjoin"] = True
                    wait["protectinvite"] = True
                    wait["protectqr"] = True
                    try:
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.findAndAddContactsByMid(op.param3)
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        pass

            if op.param3 in admin:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["protectjoin"] = True
                    wait["protectinvite"] = True
                    wait["protectqr"] = True
                    try:
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.findAndAddContactsByMid(op.param3)
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        pass

            if op.param3 in staff:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["protectjoin"] = True
                    wait["protectinvite"] = True
                    wait["protectqr"] = True
                    try:
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.findAndAddContactsByMid(op.param3)
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        pass

            if op.param3 in Bots:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["protectjoin"] = True
                    wait["protectinvite"] = True
                    wait["protectqr"] = True
                    try:
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.findAndAddContactsByMid(op.param3)
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        pass
#-------------------------------------------------------------------------------------------------------------------------------
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    if (wait["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        line.sendMessage(op.param1, wait["message"])

        if op.type == 55:
            try:
                if op.param1 in Setmain["famzreadPoint"]:
                   if op.param2 in Setmain["famzreadMember"][op.param1]:
                       pass
                   else:
                       Setmain["famzreadMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass

        if op.type == 55:
            if op.param2 in wait["blacklist"]:
               try:
                   line.kickoutFromGroup(op.param1,[op.param2])
               except:
                   pass
                   
        if op.type ==  26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if wait ["Danger"] == True:
            	if msg._from not in Team:
                    if msg.text in [".js","!js",".sikat","!sikat","sikat","Bubar",".bubar","!bubar",".cipok","!cupok","Cleanse","!cleanse",".cleanse","Kickall","!kickall",".kickall","mayhem","Ratakan","bubarkan","Nuke","nuke",".nuke","Bypass","bypass",".bypass","hancurkan","!malam","winebot",".malam","malam","salken","matane","ambyar",".","cawet","pass"]:
                        line.kickoutFromGroup(receiver,[sender])

        if op.type == 25 or op.type == 26:
            print ("[25/26] OPMSG")
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 1:
                 if msg._from in admin:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = line.Talk.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            line.sendMessage(msg.to, "✓Berhasil Menambahkan Gambar")
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False

               if msg.contentType == 1:
                   if msg._from in admin:
                       if mid in Setmain["famzfoto"]:
                            path = line.downloadObjectMsg(msg_id)
                            del Setmain["famzfoto"][mid]
                            line.updateProfilePicture(path)
                            line.sendMessage(msg.to, "✓ᴘʀᴏғɪʟᴇ ᴘʜᴏᴛᴏ\nsᴜᴄᴄᴇssғᴜʟʟʏ ᴄʜᴀɴɢᴇᴅ")
                     
               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        line.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "help":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               line.sendMessage(msg.to,helpMessage)

                        if cmd == "bot on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                                line.sendMessage(msg.to, "✓ᴛʜᴇ ʙᴏᴛ ɪs ʀᴇᴀᴅʏ")
                                
                        elif cmd == "bot off":
                            if msg._from in admin:
                                wait["selfbot"] = False
                                line.sendMessage(msg.to, "✘ʙᴏᴛ ʜᴀs ʙᴇᴇɴ ᴅɪsᴀʙʟᴇᴅ")
                                
                        if cmd == "cekbot":
                            if msg._from in admin:
                                try:line.kickoutFromGroup(to, [mid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has1 == "OK":sil1 = "✓siap terima perintah"
                                else:sil1 = "✖ sedang limit boss"
                                line.sendMessage(to, "> status {}".format(sil1))
                               
                        elif cmd == "me" or text.lower() == '.me':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               contact = line.getContact(sender)
                               line.sendMessage(msg.to, None,contentMetadata={'mid': sender}, contentType=13)

                        elif text.lower() == "mid":
                               line.sendMessage(msg.to, msg._from)

                        elif ("Info " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = line.getContact(key1)
                               line.sendMessage(msg.to, "•➤ ɴᴀᴍᴀ : "+str(mi.displayName)+"\n•➤ ᴍɪᴅ : " +key1+"\n•➤ sᴛᴀᴛᴜs ᴍsɢ : "+str(mi.statusMessage))
                               line.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(line.getContact(key1)):
                                   line.sendVideoWithURL(msg.to, 'https://profile.line-scdn.net/'+str(mi.picturePath)+'/vp.small')
                               else:
                                   line.sendImageWithURL(msg.to, 'https://profile.line-scdn.net/'+str(mi.picturePath))
                              
                        elif cmd  == "midbot":
                          if msg._from in admin:
                              line.sendMessage(msg.to, mid)
                              
                        elif cmd == "status":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "===[[🔧sᴇᴛᴛɪɴɢ - ʙᴏᴛs🔧]]===\n\n"                             
                                if wait["autoJoin"] == True: md+= "􁤁􀇜•➤ : ✓ᴀᴜᴛᴏᴊᴏɪɴ\n"
                                else: md+= "􀔃•➤ : ✘ᴀᴜᴛᴏᴊᴏɪɴ\n"                       
                                if wait["autoLeave"] == True: md+= "􁤁􀇜•➤ : ✓ᴀᴜᴛᴏʟᴇᴀᴠᴇ\n"
                                else: md+= "•➤ : ✘ᴀᴜᴛᴏʟᴇᴀᴠᴇ\n"
                                if wait["protectqr"] == True: md+= "􁤁􀇜•➤ : ✓ᴘʀᴏᴛᴇᴄᴛϙʀ\n"
                                else: md+= "•➤ : ✘ᴘʀᴏᴛᴇᴄᴛϙʀ\n"
                                if wait["protectinvite"] == True: md+= "􁤁􀇜•➤ : ✓ᴘʀᴏᴛᴇᴄᴛɪɴᴠɪᴛᴇ\n"
                                else: md+= "•➤ : ✘ᴘʀᴏᴛᴇᴄᴛɪɴᴠɪᴛᴇ\n"
                                if wait["protectjoin"] == True: md+= "􁤁􀇜•➤ : ✓ᴘʀᴏᴛᴇᴄᴛᴊᴏɪɴ\n"
                                else: md+= "•➤ : ✘ᴘʀᴏᴛᴇᴄᴛᴊᴏɪɴ\n"
                                if wait["protectkick"] == True: md+= "􁤁􀇜•➤ : ✓ᴘʀᴏᴛᴇᴄᴛᴋɪᴄᴋ\n"
                                else: md+= "•➤ : ✘ᴘʀᴏᴛᴇᴄᴛᴋɪᴄᴋ\n"
                                if wait["protectcancel"] == True: md+= "􁤁􀇜•➤ : ✓ᴘʀᴏᴛᴇᴄᴛᴄᴀɴᴄᴇʟ\n"
                                else: md+= "•➤ : ✘ᴘʀᴏᴛᴇᴄᴛᴄᴀɴᴄᴇʟ\n"
                                if wait["protectantijs"] == True: md+= "􁤁􀇜•➤ : ✓ᴘʀᴏᴛᴇᴄᴛᴀɴᴛɪᴊs\n"
                                else: md+= "•➤ : ✘ᴘʀᴏᴛᴇᴄᴛᴀɴᴛɪᴊs\n"
                                line.sendMessage(msg.to, md+"\nsᴇᴛᴛɪɴɢ ᴜᴘᴅᴀᴛᴇ\n⏰ : "+ datetime.strftime(timeNow,'%H:%M:%S')+"\n📆 : "+ datetime.strftime(timeNow,'%d-%m-%Y')+"\n=======================")
                                
                        elif text.lower() == "refresh":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   line.removeAllMessages(op.param2)
                                   line.sendMessage(msg.to, "✓sᴜᴄᴄᴇss")
                               except:
                                   pass
                                
                        elif text.lower() == "khilaf":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                client = LINE(token,appName=appF)
                                x = client.getGroup(msg.to)
                                nami = [contact.mid for contact in x.members]
                                abort = False
                                targetk = []
                                cms = 'kick.js gid={} token={} app={}'.format(to,token,appF)
                                for a in nami:
                                    if a not in admin and a not in Bots:
                                        targetk.append(a)
                                if msg._from not in admin:
                                    for m in nami:
                                        if m in admin and a not in Bots:
                                            abort = True
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                if abort:
                                    for m in admin:
                                        line.sendMessage(to,'Cannot destroy {} ,there are my admin'.format(x.name))
                                        line.sendText(m,'User trying to destroy your room.')
                                        line.sendContact(m,msg._from)
                                else:
                                    line.sendMessage(to,'Please wait to destroy {}'.format(x.name))
                                    success = execute_js(cms)
                                    if success:
                                        line.sendMessage(to,'Done Execute success')
                                    else:
                                        line.sendMessage(to,'error')
                                
                        elif text.lower() == "sampah":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                x = line.getGroup(msg.to)
                                anu = x.id
                                if x.invitee == None:nama = []
                                else:nama = [contact.mid for contact in x.invitee]
                                targets = []
                                for a in nama:
                                    if a not in admin and a not in Bots:
                                        targets.append(a)
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                cms = 'baypass.js gid={} token={} app={}'.format(anu,token,appF)
                                for a in nami:
                                    if a not in admin and a not in Bots:
                                        targetk.append(a)
                                for y in targets:
                                    cms += ' uid={}'.format(y)
                                for y in targetk:
                                    cms += ' uik={}'.format(y)
                                print(cms)
                                success = execute_js(cms)
#====Baypass dari luar room==========
                        if text.startswith('pass '):
                            if msg._from in admin:
                                text = msg.text.split()
                                number = text[1]
                                if number.isdigit():
                                    groups = line.getGroupIdsJoined()
                                    if int(number) < len(groups) and int(number) >= 0:
                                        groupid = groups[int(number)]
                                        try:
                                            x = line.getGroup(groupid)
                                            anu = x.id
                                            if x.invitee == None:nama = []
                                            else:nama = [contact.mid for contact in x.invitee]
                                            targets = []
                                            for a in nama:
                                                if a not in admin and a not in Bots:
                                                    targets.append(a)
                                            nami = [contact.mid for contact in x.members]
                                            targetk = []
                                            cms = 'baypass.js gid={} token={} app={}'.format(anu,token,appF)
                                            for a in nami:
                                                if a not in admin and a not in Bots:
                                                    targetk.append(a)
                                            for y in targets:
                                                cms += ' uid={}'.format(y)
                                            for y in targetk:
                                                cms += ' uik={}'.format(y)
                                            print(cms)
                                            success = execute_js(cms)
                                            if success:
                                                line.sendMessage(msg.to,"Succes Baypass \n " + str(x.name))
                                            else:
                                                line.sendMessage(msg.to,"Limit Bose")
                                        except:
                                            pass
    
                        elif cmd == "restart":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               line.sendMessage(msg.to, "✓ʀᴇsᴛᴀʀᴛɪɴɢ")
                               Setmain["restartPoint"] = msg.to
                               restartBot()
                               
                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "•➤ ʙᴏᴛ ʀᴜɴ :\n" +waktu(eltime)
                               line.sendMessage(msg.to,bot)

                        elif cmd == "absen" or cmd == "respon":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["protectjoin"] = False
                                wait["protectinvite"] = False
                                wait["protectqr"] = False
                                line.sendMessage(msg.to, wait["Response"])
                                     
                        elif cmd == "out":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = line.getGroup(msg.to)                                
                                line.leaveGroup(msg.to)
#====CMD Ngeluarin Bot==========
                        if cmd.startswith('out '):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                text = msg.text.split()
                                number = text[1]
                                if number.isdigit():
                                    groups = line.getGroupIdsJoined()
                                    if int(number) < len(groups) and int(number) >= 0:
                                        groupid = groups[int(number)]
                                        group = line.getGroup(groupid)
                                        target = sender
                                        try:
                                            line.getGroup(groupid)
                                            line.sendMessage(groupid,"we were forced out\nplease contact the owner")
                                            line.leaveGroup(groupid)
                                            line.sendMessage(msg.to,"Succes Leave to\n " + str(group.name))
                                        except:
                                            line.sendMessage(msg.to,"I no there baby")
#========================
                        elif ("/ti/g/" in msg.text):
                            link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                            links = link_re.findall(text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                    n_links.append(l)
                            for ticket_id in n_links:
                                group = line.findGroupByTicket(ticket_id)
                                line.acceptGroupInvitationByTicket(group.id,ticket_id)
                                  
                        elif cmd == "sp" or cmd == "speed":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                get_group_time_start = time.time()
                                get_group = line.getGroupIdsJoined()
                                get_group_time = time.time() - get_group_time_start
                                line.sendMessage(msg.to, "%s sᴇᴄᴏɴᴅs" % (get_group_time))
                                
                        elif cmd == "myfriend":
                          if msg._from in admin:
                            contactlist = line.getAllContactIds()
                            kontak = line.getContacts(contactlist)
                            num=1
                            msgs= "===[[👫ғʀɪᴇɴᴅʟɪsᴛ👫]]===\n"
                            for ids in kontak:
                                msgs+= "\n%i. %s" % (num, ids.displayName)
                                num=(num+1)
                            msgs+= "\n\nᴛᴏᴛᴀʟ :「%i」ғʀɪᴇɴᴅ" % len(kontak)
                            line.sendMessage(msg.to, msgs+"\n====================")
                            
                        elif cmd == "glist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = line.getGroupIdsJoined()
                               for i in gid:
                                   G = line.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "" + str(a) + ". " +G.name+ "\n"
                               line.sendMessage(msg.to, "===[[🏠ɢʀᴏᴜᴘʟɪsᴛ🏠]]===\n\n"+ma+"\nᴛᴏᴛᴀʟ :「"+str(len(gid))+"」ɢʀᴏᴜᴘ\n====================")
#=====Ambil qr dari luar room=======
                        if cmd.startswith('qr no '):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                text = msg.text.split()
                                number = text[0]
                                if number.isdigit():
                                    groups = line.getGroupIdsJoined()
                                    if int(number) < len(groups) and int(number) >= 0:
                                        if msg.toType == 2:
                                            groupid = groups[int(number)]
                                            group = line.getGroup(groupid)
                                            if group.preventedJoinByTicket == True:
                                                group.preventedJoinByTicket = False
                                                line.updateGroup(group)
                                            gurl = line.reissueGroupTicket(groupid)
                                            line.sendMessage(msg.to,"Silahkan Masuk Boskuh\n " + str(group.name))
                                            line.sendMessage(msg.to,'http://line.me/R/ti/g/'+gurl)

                        elif cmd == "listbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                a = 0
                                for m_id in Bots:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +line.getContact(m_id).displayName + "\n"
                                line.sendMessage(msg.to, "===[[💀ʟɪsᴛʙᴏᴛ💀]]===\n\n"+ma+"\nᴛᴏᴛᴀʟ :「%s」ʙᴏᴛs\n==================" %(str(len(Bots))))
                                
                        elif cmd == "listadmin":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                md = ""
                                a = 0
                                b = 0
                                c = 0
                                d = 0
                                for m_id in owner:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +line.getContact(m_id).displayName + "\n"
                                for m_id in admin:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +line.getContact(m_id).displayName + "\n"
                                for m_id in staff:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +line.getContact(m_id).displayName + "\n"
                                for m_id in Bots:
                                    d = d + 1
                                    end = '\n'
                                    md += str(d) + ". " +line.getContact(m_id).displayName + "\n"
                                line.sendMessage(msg.to, "===[[🎓ʟɪsᴛᴀᴅᴍɪɴ🎓]]===\n\n🔰ᴏᴡɴᴇʀ :\n"+md+"\n🔰ᴀᴅᴍɪɴ :\n"+ma+"\n🔰sᴛᴀғғ :\n"+mb+"\n🔰Bots :\n"+mc+"\nᴛᴏᴛᴀʟ :「%s」ᴀᴅᴍɪɴʟɪsᴛ\n====================" %(str(len(owner)+len(admin)+len(staff)+len(creator))))
                                
                        elif cmd == "open":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = line.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   line.updateGroup(X)
                                   line.sendMessage(msg.to, "✓ᴏᴘᴇɴ ᴜʀʟ")

                        elif cmd == "close":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = line.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   line.updateGroup(X)
                                   line.sendMessage(msg.to, "✘ᴄʟᴏsᴇᴅ ᴜʀʟ")

                        elif cmd == "changePicture":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["changePicture"] = True
                                line.sendMessage(msg.to, "📷sᴇɴᴅ ᴛʜᴇ ᴘʜᴏᴛᴏ...")
                                
                        elif cmd == "updatefoto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["famzfoto"][mid] = True
                                line.sendMessage(msg.to, "📷sᴇɴᴅ ᴛʜᴇ ᴘʜᴏᴛᴏ...")
                                
                        elif cmd.startswith("myname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = line.getProfile()
                                profile.displayName = string
                                line.updateProfile(profile)
                                line.sendMessage(msg.to, "✓sᴜᴄᴄᴇss " + string + "")
                                
                        elif cmd == 'all' or cmd == 'tagall':
                          if msg._from in admin:
                            members = []
                            if msg.toType == 1:
                                room = line.getCompactRoom(to)
                                members = [mem.mid for mem in room.contacts]
                            elif msg.toType == 2:
                                group = line.getCompactGroup(to)
                                members = [mem.mid for mem in group.members]
                            else:
                                return line.sendMessage(msg.to, '✘ғᴀɪʟᴇᴅ ᴍᴇɴᴛɪᴏɴ ᴀʟʟ ᴍᴇᴍʙᴇʀs')
                            if members:
                                famzmention(to, members)

                        if ("Kick " in msg.text):
                            if msg._from in admin:
                                start = time.time()
                                time.sleep(0.00001)
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                targets = []
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    if target not in Team:
                                        try:
                                            wait["blacklist"][target] = True
                                            wait["protectjoin"] = True
                                            wait["protectinvite"] = True
                                            wait["protectqr"] = True
                                            line.kickoutFromGroup(msg.to, [target])
                                        except:
                                            pass

                        elif "Lkick " in msg.text:
                          if msg._from in admin:
                             start = time.time()
                             time.sleep(0.00001)
                             nk0 = msg.text.replace("Lkick ","")
                             nk1 = nk0.lstrip()
                             nk2 = nk1.replace("@","")
                             nk3 = nk2.rstrip()
                             _name = nk3
                             gs = line.getGroup(msg.to)
                             targets = []
                             cms = 'kick.js gid={} token={} app={}'.format(to,token,appF)
                             for s in gs.members:
                                 if _name in s.displayName:
                                    targets.append(s.mid)
                             if targets == []:
                                 line.sendMessage(msg.to, "✘ᴜsᴇʀ ᴅᴏᴇs ɴᴏᴛ ᴇxɪsᴛ")
                                 pass
                             else:
                                 for target in targets:
                                    if target not in Team:
                                      try:
                                          cms += ' uid={}'.format(target)
                                          success = execute_js(cms)
                                          if success:
                                              line.sendMessage(msg.to,'Execute success')
                                          else:
                                              line.sendMessage(msg.to,'limit')
                                      except:
                                          pass

                        elif ("Addfriend " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           line.findAndAddContactsByMid(target)
                                           line.sendMessage(msg.to,"Berhasil menambahkan teman")
                                       except:
                                           pass

                        elif ("Sbadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           line.findAndAddContactsByMid(target)
                                           line.sendMessage(msg.to,"Berhasil menambahkan teman")
                                       except:
                                           pass
                                          
                        elif ("Addadmin " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in creator:
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                targets = []
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    if target not in admin:
                                        admin.append(target)
                                        line.sendMessage(msg.to, "✓sᴜᴄᴄᴇss ᴀᴅᴅ ᴀᴅᴍɪɴ")
                                    else:
                                        line.sendMessage(msg.to, "sudah menjadi anggota ᴀᴅᴍɪɴ")

                        elif ("Addstaff " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                targets = []
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    if target not in staff:
                                        staff.append(target)
                                        line.sendMessage(msg.to, "✓sᴜᴄᴄᴇss ᴀᴅᴅ staff")
                                    else:
                                        line.sendMessage(msg.to, "sudah menjadi anggota staff")

                        elif ("Addbots " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                targets = []
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    if target not in Bots:
                                        Bots.append(target)
                                        line.sendMessage(msg.to, "✓sᴜᴄᴄᴇss ᴀᴅᴅ Bots")
                                    else:
                                        line.sendMessage(msg.to, "sudah menjadi anggota Bots")

                        elif ("Delladmin " in msg.text):
                            if msg._from in creator:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Team:
                                       try:
                                           admin.remove(target)
                                           line.sendMessage(msg.to, "✓sᴜᴄᴄᴇss ᴅᴇʟᴇᴛᴇ ᴀᴅᴍɪɴ")
                                       except:
                                           pass

                        elif ("Dellstaff " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Team:
                                       try:
                                           staff.remove(target)
                                           line.sendMessage(msg.to, "✓sᴜᴄᴄᴇss ᴅᴇʟᴇᴛᴇ sᴛᴀғғ")
                                       except:
                                           pass

                        elif ("Dellbots " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Team:
                                       try:
                                           Bots.remove(target)
                                           line.sendMessage(msg.to, "✓sᴜᴄᴄᴇss ᴅᴇʟᴇᴛᴇ ʙᴏᴛs")
                                       except:
                                           pass

                        elif cmd == "banlist" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              wait["protectjoin"] = False
                              wait["protectinvite"] = False
                              wait["protectqr"] = False
                              if wait["blacklist"] == {}:
                                line.sendMessage(msg.to,"Tidak ada blacklist")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +line.getContact(m_id).displayName + "\n"
                                line.sendMessage(msg.to,"Lea_Alphat Blacklist User\n\n"+ma+"\nTotal「%s」Blacklist User" %(str(len(wait["blacklist"]))))
                                       
                        elif cmd == "clearban" or text.lower() == 'cban':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              ragets = line.getContacts(wait["blacklist"])
                              mc = "「%i」" % len(ragets)
                              line.sendMessage(msg.to, mc+": Blacklist Dibebaskan")
                              wait["blacklist"] = {}
                              wait["protectjoin"] = False
                              wait["protectinvite"] = False
                              wait["protectqr"] = False

                        elif 'Set response: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set response: ','')
                              if spl in [""," ","\n",None]:
                                  line.sendMessage(msg.to, "✘ғᴀɪʟᴇᴅ ᴛᴏ ʀᴇᴘʟᴀᴄᴇ ʀᴇsᴘᴏɴsᴇ")
                              else:
                                  wait["Response"] = spl
                                  line.sendMessage(msg.to, "✓ᴍsɢ ʀᴇsᴘᴏɴsᴇ ᴄʜᴀɴɢᴇᴅ\n「{}」".format(str(spl)))

    except Exception as error:
        print (error)
while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                oepoll.setRevision(op.revision)
                thread = threading.Thread(target=bot, args=(op,))
                thread.start()
    except Exception as e:
        print(e)
